/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.prog1b_ice_task4q2;

public interface iStaff {

    public int getStaffNumber();

    public String getStaffLocation();

    public String getStaffHiringProcess();
}
