/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog1b_ice_task4q2;

/**
 *
 * @author theodorav
 */
public class PROG1B_ICE_Task4Q2 {

    public static void main(String[] args) {
        
    }
}
