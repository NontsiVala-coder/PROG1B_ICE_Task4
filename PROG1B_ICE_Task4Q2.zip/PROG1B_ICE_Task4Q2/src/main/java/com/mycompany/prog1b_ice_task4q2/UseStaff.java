/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog1b_ice_task4q2;

import java.util.Scanner;

public class UseStaff {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the current staff number: ");
        int staffNumber = input.nextInt();
        input.nextLine();

        System.out.print("Enter the staff hiring location: ");
        String staffLocation = input.nextLine();

        StaffHiring hiring = new StaffHiring(staffNumber, staffLocation);

        hiring.printStaffHiring();

        input.close();
    }
}
