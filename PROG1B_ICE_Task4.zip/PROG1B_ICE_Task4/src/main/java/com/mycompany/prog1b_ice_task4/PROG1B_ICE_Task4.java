/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog1b_ice_task4;


public class PROG1B_ICE_Task4 {

    public static void main(String[] args) {

        // 1 dimensional array for the months
        String[] months = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN"};

        // 2 dimensional array
           int[][] makeovers = {
            {8, 2, 5},
            {7, 4, 5},
            {5, 5, 2},
            {2, 2, 3},
            {7, 7, 9},
            {7, 8, 5}
        };

        // Display for the headings
        System.out.println("HOME MAKEOVER REPORT");
        System.out.println("-------------------------------------------------------");
        System.out.printf("%-10s %-12s %-12s %-10s%n",
                "", "Bathrooms", "Kitchens", "Garden");

        // Display the makeover data
        for (int i = 0; i < months.length; i++) {
            System.out.printf("%-10s %-12d %-12d %-10d%n",
                    months[i],
                    makeovers[i][0],
                    makeovers[i][1],
                    makeovers[i][2]);
        }

        System.out.println();
        System.out.println("MONTHLY TOTALS");
        System.out.println("-------------------------------------------------------");

        // Calculate and display the totals for the months
        for (int i = 0; i < months.length; i++) {

            int total = 0;

            for (int j = 0; j < makeovers[i].length; j++) {
                total += makeovers[i][j];
            }

            System.out.printf("%-10s %-10d", months[i], total);

            // Display stars if total is 15 or above
            if (total >= 15) {
                System.out.print("***");
            }

            System.out.println();
        }

        System.out.println("-------------------------------------------------------");
    }
}